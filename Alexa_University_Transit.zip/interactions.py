import requests
import threading
import time
import json

GET_ALL_ROUTES  = "https://feeds.transloc.com/3/routes?agencies={0}"
GET_CURRENT_INFO = "https://feeds.transloc.com/3/vehicle_statuses?agencies={0}"
GET_STOP_INFO = "https://feeds.transloc.com/3/stops?&agencies={0}"
GET_ANNOUNCEMENTS = "https://feeds.transloc.com/3/announcements?agencies={0}"
GET_ARRIVALS = "https://feeds.transloc.com/3/arrivals?agencies={0}"

def grabAllInfo(agencyId):
	tempDict = {}
	def getAnnouncements(agencyId):
		url = GET_ANNOUNCEMENTS.format(agencyId)
		tempDict["Announcements"] = requests.get(url).json()

	def getRoutes(agencyId):
		url = GET_ALL_ROUTES.format(agencyId)
		tempDict["Routes"] = requests.get(url).json()

	def getStatus(agencyId):
		url = GET_CURRENT_INFO.format(agencyId)
		tempDict["currentInfo"] = requests.get(url).json()

	def getStopInfo(agencyId):
		url = GET_STOP_INFO.format(agencyId)
		tempDict["Stops"] = requests.get(url).json()

	def getArrivals(agencyId):
		url = GET_ARRIVALS.format(agencyId)
		tempDict["Arrivals"] = requests.get(url).json()

	threads = []
	threads.append(threading.Thread(target=getStopInfo, args=(agencyId,)))
	threads.append(threading.Thread(target=getStatus, args=(agencyId,)))
	threads.append(threading.Thread(target=getRoutes, args=(agencyId,)))
	threads.append(threading.Thread(target=getAnnouncements, args=(agencyId,)))
	threads.append(threading.Thread(target=getArrivals, args=(agencyId,)))
	for thread in threads:
		thread.start()
	for thread in threads:
		thread.join()
	return tempDict

if __name__ == '__main__':
	start = time.time()
	a = grabAllInfo('639')
	end = time.time()
	print(end - start)
	with open('example.json', 'w') as outfile:
		json.dump(a, outfile)
